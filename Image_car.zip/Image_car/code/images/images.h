/*
 * images.h
 *
 *  Created on: 2024��10��19��
 *      Author: 15955
 */

#ifndef CODE_IMAGES_H_
#define CODE_IMAGES_H_
#include "zf_common_headfile.h"
#define IMG_BLACK 0X00
#define IMG_WHITE 0Xff
#define bin_jump_num    1     //�����ĵ���
#define border_max  MT9V03X_W-2 //�߽����ֵ
#define border_min  1         //�߽���Сֵ

extern uint8    mt9v03x_image_original[MT9V03X_H][MT9V03X_W];
extern uint8    bin_image[MT9V03X_H][MT9V03X_W];

extern uint8 l_border[MT9V03X_H];//��������
extern uint8 r_border[MT9V03X_H];//��������
extern uint8 center_line[MT9V03X_H];//��������

extern float parameterB;
extern float parameterA;

extern uint8 camera_process_cnt;


void Images_Get();
void turn_to_bin(void);
uint8 otsuThreshold_fast(uint8 *image);
void image_filter(uint8(*bin_image)[MT9V03X_W]);
void image_draw_rectan();
uint8 get_start_point(uint8 start_row);
void search_l_r(uint16 break_flag, uint8(*image)[MT9V03X_W], uint16 *l_stastic, uint16 *r_stastic, uint8 l_start_x, uint8 l_start_y, uint8 r_start_x, uint8 r_start_y, uint8*hightest);
float absolute(float z);
int16 limit_a_b(int x, int a, int b);
int16 limit1(int16 x, int16 y);
void get_right(uint16 total_R);
void get_left(uint16 total_L);
void image_process(void);
void get_middle_line();
void display(void);
float deviationestimate(void);
float process_curvity(char x1, char y1, char x2, char y2, char x3, char y3);
void regression(int startline, int endline);
void Addingline( uint8 choice, uint8 startX, uint8 startY, uint8 endX, uint8 endY);
///void caculate_distance(uint8 start,uint8 end,int *border,float *slope_new,float *distance_new);
#endif /* CODE_IMAGES_H_ */
