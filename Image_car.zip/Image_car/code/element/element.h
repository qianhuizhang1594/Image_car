/*
 * element.h
 *
 *  Created on: 2024��11��5��
 *      Author: 15955
 */

#ifndef CODE_ELEMENT_ELEMENT_H_
#define CODE_ELEMENT_ELEMENT_H_
#include "zf_common_headfile.h"

extern uint8 zebra_crossing_flag = 0;
void Zebra_Crossing(void);

#endif /* CODE_ELEMENT_ELEMENT_H_ */
