/*
 * element.c
 *
 *  Created on: 2024��11��5��
 *      Author: 15955
 */

#include "zf_common_headfile.h"

#define ZERBA_CROSSING_ROW  70

uint8 zebra_crossing_flag = 0;
void Zebra_Crossing(void)
{
    uint8 zebra_row;
    int i;
    int edge_left_num = 0;
    int edge_right_num = 0;
    int edge_sum = 0;
    zebra_crossing_flag = 0;
    for(zebra_row = ZERBA_CROSSING_ROW; zebra_row < ZERBA_CROSSING_ROW+3; zebra_row++)
    {
        for(i=l_border[zebra_row];i<94;i++)
        {
            if((bin_image[zebra_row][i] == IMG_WHITE && bin_image[zebra_row][i+1] == IMG_WHITE) &&
               (bin_image[zebra_row][i+2] == IMG_BLACK && bin_image[zebra_row][i+3] == IMG_BLACK))
            {
                edge_left_num++;
            }
//            printf("%d,%d\r\n",image[zebra_row][i]);
        }
        for(i=r_border[zebra_row];i>94;i--)
        {
            if((bin_image[zebra_row][i] == IMG_WHITE && bin_image[zebra_row][i-1] == IMG_WHITE) &&
               (bin_image[zebra_row][i-2] == IMG_BLACK && bin_image[zebra_row][i-3] == IMG_BLACK))
            {
                edge_right_num++;
            }
        }
    }
    edge_sum = edge_left_num + edge_right_num;
    if(edge_sum > 200)
        edge_sum = 0;
    if(edge_left_num > 200)
        edge_left_num = 0;
    if(edge_sum >= 16)                      //ͣ��
    {
        system_delay_ms(150);
        zebra_crossing_flag = 1;
        stop_flag=1;
        Beep_ShortRing();
//        system_delay_ms(1000);

    }
    else
        zebra_crossing_flag = 0;
//    printf("%d, %d, %d ,%d\r\n",edge_left_num, edge_right_num, left[zebra_row], right[zebra_row]);
//    printf("%d, %d, %d\r\n",edge_left_num, edge_right_num, edge_sum);
}


