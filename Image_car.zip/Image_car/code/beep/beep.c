/*
 * beep.c
 *
 *  Created on: 2024��10��24��
 *      Author: 15955
 */
#include "zf_common_headfile.h"
void beep_Init(void)
{
    gpio_init(P33_10,GPO,0,GPO_PUSH_PULL);
}

void Beep_ShortRing(void)
{
    gpio_set_level(P33_10,1);
    system_delay_ms(10);
    gpio_set_level(P33_10,0);
}

