/*
 * beep.h
 *
 *  Created on: 2024��10��24��
 *      Author: 15955
 */

#ifndef CODE_BEEP_H_
#define CODE_BEEP_H_

void beep_Init(void);
void Beep_ShortRing(void);



#endif /* CODE_BEEP_H_ */
