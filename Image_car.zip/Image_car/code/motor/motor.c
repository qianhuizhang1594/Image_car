/*
 * motor.c
 *
 *  Created on: 2024��10��20��
 *      Author: 15955
 */
#include "zf_common_headfile.h"
#define  Motor_L_R ATOM0_CH0_P21_2
#define  Motor_L_D ATOM0_CH1_P21_3
#define  Motor_R_D ATOM0_CH3_P21_5
#define  Motor_R_R ATOM0_CH2_P21_4

float basis;


#define ENCODER_L         TIM2_ENCODER_CH1_P33_7     //���������������
#define ENCODER_DIR_L     TIM2_ENCODER_CH2_P33_6    //���������������

#define ENCODER_R         TIM6_ENCODER_CH1_P20_3     //�ұ�������������
#define ENCODER_DIR_R     TIM6_ENCODER_CH2_P20_0    //�ұ�������������

float speed_L;//���ֱ������ٶ�
float speed_R;//���ֱ������ٶ�

PID_Datatypedef sptr_L,sptr_R;
PID_imu_Datatypedef imu;

unsigned char stop_flag=0;


float setspeed = 150;

float Image_Error;
float divertion = 0;
float erspeed = 0;

int status = 0;
void encoder_Init()
{
    encoder_dir_init(TIM6_ENCODER,ENCODER_R,ENCODER_DIR_R);
    encoder_dir_init(TIM2_ENCODER,ENCODER_L,ENCODER_DIR_L);
}
void Motor_Init()
{
       pwm_init(Motor_L_R,12000, 0);
       pwm_init(Motor_L_D,12000, 0);
       pwm_init(Motor_R_D,12000, 0);
       pwm_init(Motor_R_R,12000, 0);

       PID_Init(&sptr_L);
       PID_Init(&sptr_R);

       imu_PID_Init(&imu);

       sptr_L.P=10;
       sptr_L.I=3;
       sptr_L.D=1;

       sptr_R.P=10;
       sptr_R.I=3;
       sptr_R.D=1;

       imu.P=20;
       imu.I=1;
       imu.D=3;
}


int16 Encoder_MTM(encoder_index_enum gptn,int n,uint8 direct)
{
    int16 Coder = 0;
    int16 CoderOut = 0;
    switch(gptn)
    {
        case TIM2_ENCODER:
            for(int i = 0;i < n;i++)
            {
                if(direct){
                Coder -=  encoder_get_count(TIM2_ENCODER);
                }
                else
                {
                Coder +=  encoder_get_count(TIM2_ENCODER);
                }

            }
            CoderOut = Coder/n;
            break;
        case TIM6_ENCODER:
            for(int i = 0;i < n;i++)
            {
                if(direct){
                    Coder +=  encoder_get_count(TIM6_ENCODER);
                }
                else
                {
                    Coder -=  encoder_get_count(TIM6_ENCODER);
                }

            }
            CoderOut = Coder/n;
            break;
        default:
            break;
    }
    encoder_clear_count(gptn);    //���������

    return CoderOut;
}
void getspeed(void)
{
    speed_L = Encoder_MTM(TIM2_ENCODER,3,1);
    speed_R = Encoder_MTM(TIM6_ENCODER,3,1);
}


void motor_set()
{
    pwm_set_duty (Motor_L_R, 1000);
    pwm_set_duty (Motor_R_D, 0);
    pwm_set_duty (Motor_L_D, 0);
    pwm_set_duty (Motor_R_R, 1000);
}
float Get_Error()
{
    for(int i=80;i>55;i--)
    {
        basis+=center_line[i]-94;
    }
    basis=basis/25;
}

void PID_output()
{
    int Increase_L=0;
    int Increase_R=0;

    if(stop_flag ==1)
        {
            pwm_set_duty(Motor_L_D,0);
            pwm_set_duty(Motor_R_D,0);
            pwm_set_duty(Motor_L_R,0);
            pwm_set_duty(Motor_R_R,0);
        }

        //PID����
        else if(stop_flag==0)
        {
            //����ʽPID����С��ֱ��
            Increase_L=MotorPID_Output(&sptr_L,speed_L,setspeed);
            Increase_R=MotorPID_Output(&sptr_R,speed_R,setspeed);
            //����ֱ��ŤתС�����з���
            divertion=imuPID_Output(erspeed,&imu);
            //PWM����
            Increase_L=Increase_L+divertion;
            Increase_R=Increase_R-divertion;
 //           if(speed_L-speed_R>350||speed_L-speed_R>350)
//                stop_flag=1;

            PWMControl(Increase_L,Increase_R);
        }
}
void PWMControl(int16 motor_duty1,int16 motor_duty2)
{
    //��ռ�ձ��޷�
    if(motor_duty1>PWM_DUTY_MAX) motor_duty1 = PWM_DUTY_MAX;
    else if(motor_duty1<-PWM_DUTY_MAX) motor_duty1 = -PWM_DUTY_MAX;

    if(motor_duty2>PWM_DUTY_MAX) motor_duty2 = PWM_DUTY_MAX;
    else if(motor_duty2<-PWM_DUTY_MAX) motor_duty2 = -PWM_DUTY_MAX;

    if(0<=motor_duty1) //���1   ��ת ����ռ�ձ�Ϊ �ٷ�֮ (1000/TIMER1_pwm_set_duty_MAX*100)
    {

        pwm_set_duty(Motor_L_R,motor_duty1);
        pwm_set_duty(Motor_L_D,0);
    }
    else                //���1   ��ת
    {

        pwm_set_duty(Motor_L_R,0);
        pwm_set_duty(Motor_L_D,-motor_duty1);
    }

    if(0<=motor_duty2) //���2   ��ת
    {

       pwm_set_duty(Motor_R_D,motor_duty2);
       pwm_set_duty(Motor_R_R,0);
    }
    else                //���2   ��ת
    {

        pwm_set_duty(Motor_R_D,0);
        pwm_set_duty(Motor_R_R,-motor_duty2);
    }
}
void Car_start()
{
    system_delay_ms(10);
    stop_flag=0;
}

void ErrorOperation()
{
    Image_Error=deviationestimate();
    erspeed=Image_Error;
}
