#ifndef  __Menu_Variable_H
#define  __Menu_Variable_H

#include "zf_common_headfile.h"
extern uint8 threshold_value_add;
extern uint8 threshold_open_or_close;
extern uint8 g_Start_Flag ;


#endif
