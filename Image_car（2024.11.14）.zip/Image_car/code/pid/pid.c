/*
 * pid.c
 *
 *  Created on: 2024��10��21��
 *      Author: 15955
 */

#include "zf_common_headfile.h"
int MotorPID_Output(PID_Datatypedef*sptr,float NowSpeed,int ExpectSpeed)
{
    int Increase;
    float iError;
    iError=ExpectSpeed-NowSpeed;
    Increase=(int)(sptr->P*(iError-sptr->LastError)+sptr->I*iError+sptr->D*(iError-2*sptr->LastError+sptr->PrevError));
    sptr->PrevError=sptr->LastError;
    sptr->LastError=iError;
    return Increase;
}
float imuPID_Output(float error,PID_imu_Datatypedef*imu)
{
    float imu_out;
    imu_out=error*imu->P+(error-imu->lasterror)*imu->D;
    imu->lasterror=error;
    return imu_out;

}
void PID_Init(PID_Datatypedef*sptr)
{
    sptr->P=0;
    sptr->I=0;
    sptr->D=0;
    sptr->LastError=0;
    sptr->PrevError=0;
}
void imu_PID_Init(PID_imu_Datatypedef*imu)
{
    imu->P=0;
    imu->I=0;
    imu->D=0;
    imu->lasterror=0;
}
