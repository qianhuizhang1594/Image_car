/*
 * pid.h
 *
 *  Created on: 2024��10��21��
 *      Author: 15955
 */
#include "zf_common_headfile.h"
#ifndef CODE_PID_H_
#define CODE_PID_H_
typedef struct
{
        float P;
        float I;
        float D;

        float LastError;
        float PrevError;

}PID_Datatypedef;
typedef struct
{
        float P;
        float I;
        float D;
        float lasterror;
}PID_imu_Datatypedef;
extern PID_Datatypedef sptr_L,sptr_R;
extern PID_imu_Datatypedef imu;


void PID_Init(PID_Datatypedef*sptr);
void imu_PID_Init(PID_imu_Datatypedef*imu);
float imuPID_Output(float erspeed,PID_imu_Datatypedef*imu);
int MotorPID_Output(PID_Datatypedef*sptr,float NowSpeed,int ExpectSpeed);
#endif /* CODE_PID_H_ */
