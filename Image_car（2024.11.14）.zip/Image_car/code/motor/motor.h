/*
 * motor.h
 *
 *  Created on: 2024��10��20��
 *      Author: 15955
 */

#ifndef CODE_MOTOR_H_
#define CODE_MOTOR_H_

#define  Motor_L_R ATOM0_CH0_P21_2
#define  Motor_L_D ATOM0_CH1_P21_3
#define  Motor_R_D ATOM0_CH2_P21_4
#define  Motor_R_R ATOM0_CH3_P21_5


extern unsigned char stop_flag;
extern float setspeed;
extern float Image_Error;
extern float basis;
extern float basis_copy;
extern float erspeed;
void Motor_Init(void);
void motor_set(void);
void PID_output(void);
void PWMControl(int16 motor_duty1,int16 motor_duty2);
void Car_start(void);
void Tracesc(void);
void ErrorOperation(void);
#endif /* CODE_MOTOR_H_ */
