/*
 * motor.c
 *
 *  Created on: 2024��10��20��
 *      Author: 15955
 */
#include "zf_common_headfile.h"
#define  Motor_L_R ATOM0_CH0_P21_2
#define  Motor_L_D ATOM0_CH1_P21_3
#define  Motor_R_D ATOM0_CH2_P21_4
#define  Motor_R_R ATOM0_CH3_P21_5

float basis;
float basis_copy;

PID_Datatypedef sptr_L,sptr_R,stop_L,stop_R;
PID_imu_Datatypedef imu;

unsigned char stop_flag=0   ;


float setspeed = 100;

float Image_Error;
float divertion = 0;
float erspeed = 0;

int status;

/***********************************************
* @brief : ������ʼ��
* @param : void
* @return:
* @date  :
* @author:
************************************************/
void Motor_Init()
{
       pwm_init(Motor_L_R,12000, 0);
       pwm_init(Motor_L_D,12000, 0);
       pwm_init(Motor_R_D,12000, 0);
       pwm_init(Motor_R_R,12000, 0);

       PID_Init(&sptr_L);
       PID_Init(&sptr_R);

       imu_PID_Init(&imu);

       sptr_L.P=67;
       sptr_L.I=67;
       sptr_L.D=19;

       sptr_R.P=72;
       sptr_R.I=65;
       sptr_R.D=20;

       imu.P=38;
       imu.I=0;
       imu.D=23;


}


/***********************************************
* @brief : �趨pwm
* @param : void
* @return:
* @date  :
* @author:
************************************************/
void motor_set()
{
    pwm_set_duty (Motor_L_R, 1000);
    pwm_set_duty (Motor_R_D, 0);
    pwm_set_duty (Motor_L_D, 0);
    pwm_set_duty (Motor_R_R, 1000);
}
/***********************************************
* @brief : ��ȡͼ�����
* @param : void
* @return:
* @date  :
* @author:
************************************************/
float Get_Error()
{
    for(int i=75;i>45;i--)
    {
        basis+=center_line_copy[i]-94;
        basis_copy+=center_line[i]-94;
    }
    basis=basis/30;
}

/***********************************************
* @brief : ����
* @param : void
* @return:
* @date  :
* @author:
************************************************/
void PID_output()
{
    int Increase_L=0;
    int Increase_R=0;
    int zero_speed_l=0;
    int zero_speed_r=0;
    Get_Error();
    if(stop_flag ==1)
        {
        setspeed=0;
        stop_L.P=10;
        stop_L.I=60;
        stop_L.D=18;

        stop_R.P=10;
        stop_R.I=60;
        stop_R.D=20;


        zero_speed_l=MotorPID_Output(&stop_L,speed_L,setspeed);
        zero_speed_r=MotorPID_Output(&stop_R,speed_R,setspeed);
        PWMControl(zero_speed_l,zero_speed_r);
        }

        //PID����
        else if(stop_flag==0)
        {

            //����ʽPID����С��ֱ��
            Increase_L=MotorPID_Output(&sptr_L,speed_L,setspeed);
            Increase_R=MotorPID_Output(&sptr_R,speed_R,setspeed);
           // printf("%d,%d,%f\r\n,",Increase_L,Increase_R,basis);
            //����ֱ��ŤתС�����з���
            divertion=imuPID_Output(basis,&imu);
            //PWM����
            Increase_L=Increase_L+divertion;
            Increase_R=Increase_R-divertion;
 //           if(speed_L-speed_R>350||speed_L-speed_R>350)
//                stop_flag=1;



            PWMControl(Increase_L,Increase_R);
        }
}
/***********************************************
* @brief : pwm���
* @param : void
* @return:
* @date  :
* @author:
************************************************/
void PWMControl(int16 motor_duty1,int16 motor_duty2)
{
    //��ռ�ձ��޷�
    if(motor_duty1>PWM_DUTY_MAX) motor_duty1 = PWM_DUTY_MAX;
    else if(motor_duty1<-PWM_DUTY_MAX) motor_duty1 = -PWM_DUTY_MAX;

    if(motor_duty2>PWM_DUTY_MAX) motor_duty2 = PWM_DUTY_MAX;
    else if(motor_duty2<-PWM_DUTY_MAX) motor_duty2 = -PWM_DUTY_MAX;

    if(0<=motor_duty1) //���1   ��ת ����ռ�ձ�Ϊ �ٷ�֮ (1000/TIMER1_pwm_set_duty_MAX*100)
    {

        pwm_set_duty(Motor_L_R,motor_duty1);
        pwm_set_duty(Motor_L_D,0);
    }
    else                //���1   ��ת
    {

        pwm_set_duty(Motor_L_R,0);
        pwm_set_duty(Motor_L_D,-motor_duty1);
    }

    if(0<=motor_duty2) //���2   ��ת
    {

       pwm_set_duty(Motor_R_R,motor_duty2);
       pwm_set_duty(Motor_R_D,0);
    }
    else                //���2   ��ת
    {

        pwm_set_duty(Motor_R_R,0);
        pwm_set_duty(Motor_R_D,-motor_duty2);
    }
}
/***********************************************
* @brief : ��������
* @param : void
* @return:
* @date  :
* @author:
************************************************/
void Car_start()
{
    system_delay_ms(10);
    stop_flag=0;
}
/***********************************************
* @brief : ״̬ѡ���趨�ٶ�
* @param : void
* @return:
* @date  :
* @author:
************************************************/
void ErrorOperation()
{

    basis=absolute(basis);
    if(Circle_Start_Flag >0 && Circle_Start_Flag <5 )
    {
        setspeed =85;
    }
    else
    {
        if(basis<14)
            {
                status = 1;//ֱ��;
            }
            else
            {
                status = 0;//���;
            }
            if(status == 1)
            {
                setspeed = 110;
            }
            else
            {

                setspeed = 100;

            }
    }

}
