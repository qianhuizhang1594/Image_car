/*
 * page_setting.h
 *
 *  Created on: 2023��3��5��
 *      Author: ֣��
 */
#include "zf_common_headfile.h"

#ifndef CODE_MENU_PAGE_SETTING_H_
#define CODE_MENU_PAGE_SETTING_H_



extern int8 line_number;
extern uint8 line_number_max;

extern int8 row_number;
extern uint8 row_number_max;

extern int8 main_line_number;
extern int8 navigation_line_number;
extern int8 Camera_line_number;






extern float increment1[4];
extern float increment2[4];
extern float increment3[3];
extern float mtspeedlevel[5];

void main_page_process(int Event_Code);
void start_page_process(int Event_Code);
void navigation_page_process(int Event_Code);
void Camera_page_process(int Event_Code);
void image_page_process(int Event_Code);


#endif /* CODE_MENU_PAGE_SETTING_H_ */
