/*
 * mymenu.h
 *
 *  Created on: 2023��4��14��
 *      Author: ֣��
 */

#ifndef CODE_CPU2_MENU_MYMENU_H_
#define CODE_CPU2_MENU_MYMENU_H_

#include "menu.h"
#include "Font.h"
#include "page_setting.h"


extern int point_num;
extern int start_flag;

#endif /* CODE_CPU2_MENU_MYMENU_H_ */
