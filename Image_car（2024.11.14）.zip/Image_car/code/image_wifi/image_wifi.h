/*
 * image_wifi.h
 *
 *  Created on: 2024��11��7��
 *      Author: 15955
 */

#ifndef CODE_IMAGE_WIFI_IMAGE_WIFI_H_
#define CODE_IMAGE_WIFI_IMAGE_WIFI_H_
#include "zf_common_headfile.h"

extern uint8 g_wifi_image_open_flag;
extern uint8 image_copy[MT9V03X_H][MT9V03X_W];

#define WIFI_SSID_TEST              "MiSaKaTEST"
#define WIFI_PASSWORD_TEST          "123456789"

void Wifi_Image_Init(void);
void Wifi_Image_Send_Camera(void);


#endif /* CODE_IMAGE_WIFI_IMAGE_WIFI_H_ */
